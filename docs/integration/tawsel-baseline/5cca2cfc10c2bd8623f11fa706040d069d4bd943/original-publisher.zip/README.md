# Tawsel car/motorcycle local handoff

Start with [the as-built handoff](docs/ERP-INTEGRATION-HANDOFF.md), then [the ERP reading order](docs/erp/README.md). Verify before use: `node scripts/verify-erp-release.mjs .`. Install the reference in `dist/erp-reference/` with `npm ci --ignore-scripts`; follow the [quickstart](docs/erp/consumer-quickstart.md).

This package contains public contracts/client/reference artifacts and recorded local evidence. It contains no live credentials, deployed-release claim or real ERP implementation. Historical internal-source/private-log links describe provenance and are not external setup prerequisites.
